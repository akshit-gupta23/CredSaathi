# CredSaathi

**Building Trust. Creating Credit.**

CredSaathi is a prototype for alternative credit assessment of gig workers, initially focused on delivery partners working with Zomato and Swiggy. It analyses earnings information and bank-statement transactions to estimate income stability and repayment capacity, then presents a credit assessment and loan simulation.

## Project files

- `frontend.html` — browser-based user interface and upload/review flow.
- `backend-engine.js` — JavaScript document-processing and credit-assessment engine used by the frontend.

## Run locally

1. Download or clone this repository.
2. Keep `frontend.html` and `backend-engine.js` in the same folder.
3. Open `frontend.html` in a modern browser. If browser restrictions prevent local file processing, serve the folder with a simple local web server instead.
4. Upload a bank statement and/or a Zomato or Swiggy earnings document in the relevant upload section. Review and correct extracted values where needed.

The frontend loads Tesseract.js and PDF.js from public CDNs. The engine uses local OCR/PDF text extraction where available and contains a Claude vision transcription fallback. The fallback currently calls the Anthropic Messages API directly from the browser without a configured authentication header; it therefore requires implementation of a secure server-side API integration before it can work reliably. Do not put an API key in browser code.

## Current scope and limitations

- Prototype scope is Zomato and Swiggy delivery partners.
- Extracted document data may need manual review and correction.
- Credit scores and loan simulations are indicative prototype outputs, not lending decisions or financial advice.
- No PayPal API, PayPal Checkout, or PayPal Sandbox integration is included in this repository.
- This is a prototype, not a production-ready lending or payment system.

## Technology visible in the source

- HTML, CSS and JavaScript
- Tesseract.js for browser OCR
- PDF.js for PDF text extraction
- Anthropic Claude Sonnet 4.6 is referenced in the document-transcription fallback code; the API call needs secure authentication/backend setup before it can be used.
